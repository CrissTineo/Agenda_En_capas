# Agenda

![#1589F0](https://via.placeholder.com/15/1589F0/000000?text=+) Video del proyecto: 

https://youtu.be/byU8dt0M4Lw

### Archivos para la base de datos (SQL SERVER) // Hacer debidos cambios en la conexion en la capa de datos con respecto a su ordenador:

- TransactSQLnoSCRIPT.txt
- scriptDataBASE.txt

![#f03c15](https://via.placeholder.com/15/f03c15/000000?text=+)
`Dichos archivos no son parte del proyecto en C#, son los script y transact para crear la base de datos y la tabal que utilize para la agenda`. 
